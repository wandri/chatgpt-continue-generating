"use strict";
(() => {
  // src/constant.ts
  var DEFAULT_INTERVAL = 1e3;
  var STORAGE_KEY_INTERVAL = "gpt_interval";
  var STORAGE_KEY_IS_DISABLED = "gpt_is_disabled";

  // src/content.ts
  chrome.storage.sync.get(
    [STORAGE_KEY_INTERVAL, STORAGE_KEY_IS_DISABLED],
    (result) => {
      const interval = result[STORAGE_KEY_INTERVAL] || DEFAULT_INTERVAL;
      if (!result[STORAGE_KEY_IS_DISABLED]) {
        setInterval(() => clickOnContinueButton(), interval);
      }
    }
  );
  function clickOnContinueButton() {
    const buttons = document.querySelectorAll("button");
    for (let i = 0; i < buttons.length; i++) {
      const button = buttons.item(i);
      if (button.innerText.includes("Continue generating")) {
        const randomTimeoutToAvoidDetection = Math.random() * 1e3;
        setTimeout(() => {
          button.click();
        }, randomTimeoutToAvoidDetection);
        console.log("Continue generating");
        break;
      }
    }
  }
})();
