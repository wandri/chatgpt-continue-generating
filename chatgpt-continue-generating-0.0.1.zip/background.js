"use strict";
(() => {
  // src/manifest.json
  var manifest_default = {
    manifest_version: 3,
    name: "ChatGpt - Unlock long text",
    short_name: "ChatGpt - Unlocked",
    version: "0.0.1",
    description: 'Unlock automatic generation of long text, on chat.openai.com, by auto-clicking on "continue generating" button.',
    permissions: [
      "notifications",
      "storage"
    ],
    content_security_policy: {
      extension_pages: "script-src 'self'; object-src 'self';"
    },
    background: {
      service_worker: "background.js"
    },
    content_scripts: [
      {
        matches: [
          "https://chat.openai.com/*"
        ],
        js: [
          "content.js"
        ]
      }
    ],
    icons: {
      "16": "assets/icon/icon16.png",
      "32": "assets/icon/icon32.png",
      "48": "assets/icon/icon48.png",
      "128": "assets/icon/icon128.png"
    },
    host_permissions: [
      "https://chat.openai.com/*"
    ],
    action: {
      default_icon: {
        "16": "assets/icon/icon16.png",
        "32": "assets/icon/icon32.png",
        "48": "assets/icon/icon48.png",
        "128": "assets/icon/icon128.png"
      },
      default_popup: "index.html"
    }
  };

  // src/background.ts
  var updateDescription = ``;
  var currentVersion = manifest_default.version;
  var openAiChatUrl = "https://chat.openai.com/*";
  function getOpenAiTabs() {
    return chrome.tabs.query({ url: openAiChatUrl });
  }
  chrome.runtime.onInstalled.addListener(async (details) => {
    if (details.reason === "install") {
      const openAiTabs = await getOpenAiTabs();
      if (openAiTabs.length > 0) {
        chrome.notifications.create({
          type: "basic",
          iconUrl: "assets/icon/icon128.png",
          title: "Reload ChatGPT Tabs?",
          message: "Would you like to reload your ChatGPT tabs to activate the extension?",
          buttons: [{ title: "Reload" }],
          priority: 2
        });
      }
    } else if (details.reason === "update") {
      const openAiTabs = await getOpenAiTabs();
      if (openAiTabs.length > 0) {
        chrome.notifications.create({
          type: "basic",
          iconUrl: "assets/icon/icon128.png",
          title: `${manifest_default.short_name} was updated!`,
          message: `Your extension has been updated to the version ${currentVersion}. ${updateDescription}`,
          buttons: [{ title: "Great! Reload CHAT_GPT Tabs!" }],
          priority: 2
        });
      }
    }
  });
  chrome.notifications.onButtonClicked.addListener(async () => {
    const tabs = await getOpenAiTabs();
    tabs.forEach((tab) => {
      if (tab.id) {
        chrome.tabs.reload(tab.id);
      }
    });
  });
})();
